"""Compile fixed-proposal postburn with the existing NumPy Generator stream."""
import inspect,math
import numpy as np
from numba import njit
import parameter_mcmc_tuned as pm
from steady_kalman_target import target

@njit(cache=True,fastmath=False,nogil=True)
def postburn(y,t,lp,chol,rng,kept,lower,upper,ymean):
    trace=np.empty((kept,3));accept=np.zeros(kept)
    for i in range(kept):
        proposal=t+chol@rng.normal(size=3)
        value=-np.inf
        if (lower[0]<=proposal[0]<=upper[0] and lower[1]<=proposal[1]<=upper[1] and lower[2]<=proposal[2]<=upper[2]):
            value=target(y,proposal[0],proposal[1],proposal[2],ymean)
        if math.log(rng.random())<value-lp:
            t=proposal;lp=value;accept[i]=1.
        trace[i]=t
    return trace,accept

def finish(y,t,lp,chol,rng,kept,bounds,ymean):
    lower=np.asarray([b[0] for b in bounds]);upper=np.asarray([b[1] for b in bounds])
    trace,accept=postburn(y,t,lp,chol,rng,kept,lower,upper,ymean)
    return trace,float(accept.mean())

def make_chain():
    namespace=dict(pm.__dict__);namespace.update(fast_target=target,finish=finish)
    source=inspect.getsource(pm.chain).replace('rng=np.random.default_rng(seed)','rng=np.random.default_rng(seed)\n    ymean=float(np.mean(y))').replace('bd._sv_transformed_log_posterior(y,*t)','fast_target(y,*t,ymean)').replace('range(burn+kept)','range(burn)').replace('return trace[burn:],float(accept[burn:].mean())','return finish(y,t,lp,chol,rng,kept,bounds,ymean)')
    exec(compile(source,__file__,'exec'),namespace)
    return namespace['chain']
