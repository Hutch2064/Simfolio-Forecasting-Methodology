"""Avoid redundant finite-input cleanup and repeated exact reductions."""
import inspect
import numpy as np
from simfolio_forecasting_methodology.models.numerical import bdes_fastmap as bd

def make():
    original=bd._bdes_multiscale_components;source=inspect.getsource(original)
    for old,new in [('np.nanmean(','np.mean('),('np.nanvar(','np.var('),('np.nanstd(','np.std(')]:source=source.replace(old,new)
    cleanup='h = np.asarray(h_path, dtype=float); finite = h[np.isfinite(h)]; fill = float(np.nanmedian(finite)) if finite.size else 0.0\n    h = np.clip(np.nan_to_num(h, nan=fill, posinf=fill, neginf=fill), -18.0, 18.0)'
    assert source.count(cleanup)==1
    source=source.replace(cleanup,'h = np.clip(np.asarray(h_path, dtype=float), -18.0, 18.0)')
    source=source.replace('signal = np.abs(b) * np.std(q, axis=0)','q_std = np.std(q, axis=0)\n    signal = np.abs(b) * q_std',1)
    source=source.replace('post_signal = np.abs(b) * np.std(q, axis=0)','post_signal = np.abs(b) * q_std')
    source=source.replace('"hbar": float(np.mean(h))','"hbar": ell')
    namespace=dict(bd.__dict__);exec(compile(source,__file__,'exec'),namespace)
    finite=namespace['_bdes_multiscale_components']
    def result(path,*args,**kwargs):
        if not np.all(np.isfinite(path)):return original(path,*args,**kwargs)
        return finite(path,*args,**kwargs)
    return result
